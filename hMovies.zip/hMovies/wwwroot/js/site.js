﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// api links
const apiUrl = 'https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=97e35975328a9e003cc7a4df1050fe9b&page=1';
const imPath = "https://image.tmdb.org/t/p/w185";
const imPathBig = "https://image.tmdb.org/t/p/w780";
const apiSearchURL =
    "https://api.themoviedb.org/3/search/movie?&api_key=97e35975328a9e003cc7a4df1050fe9b&query=";
// elements from html.
const main = document.getElementById("main");
const form = document.getElementById("form");
const search = document.getElementById("search");
const titleButton = document.getElementById("titleButton")
const message = document.createElement('mess');
message.innerHTML = 'Oops, no movies!'
form.appendChild(message);
/* call showmovies, if there is a query then the function will run.*/
showMovies(apiUrl);
function showMovies(url) {
    
    fetch(url).then(res => res.json())
        .then(function (data) {
            data.results.forEach(element => {


                // elements of the movies, descriptionbig, imbig, release date are shown if user clicks on movie.
                const el = document.createElement('div');
                const image = document.createElement('img');
                const text = document.createElement('h2');
                const desc = document.createElement('overview');
                const rate = document.createElement('rating');
                var imBig = new Image(100,200);
                const descriptionBig = document.createElement('description');
                const el2 = document.createElement('div2');
                const releaseDate = document.createElement('releaseDate');
                const bigTitle = document.createElement('h3');
                
                text.innerHTML = `${element.title}`;
                image.src = imPath + element.poster_path;
                desc.innerHTML = `${element.overview}`
                rate.innerHTML = `Score: ${element.vote_average}`
                imBig.src = imPathBig + element.poster_path;
                descriptionBig.innerHTML = `${element.overview}`
                releaseDate.innerHTML = `Release Date: ${element.release_date}`
                bigTitle.innerHTML = `${element.title}`;

                el.appendChild(image);
                el.appendChild(text);
                

                
                main.appendChild(el);


                el.addEventListener("mouseenter", function (event){
                    el.appendChild(desc);
                    
                    
                }, false)



                el.addEventListener("mouseleave", function (event) {
                    el.removeChild(desc);
                    
                })

                el.addEventListener("click", function (event) {

                    main.innerHTML=''
                    
                    el2.appendChild(bigTitle);
                    el2.appendChild(descriptionBig);
                    el2.appendChild(rate);
                    el2.appendChild(releaseDate);
                    el2.appendChild(imBig);
                    main.appendChild(el2);
                    
                    


                })

            });
            
            
        });

   
}



form.addEventListener("submit", (e) => {
    e.preventDefault();
    main.innerHTML = '';

    const query = search.value;
    /* append query to end*/
    if (query) {
        showMovies(apiSearchURL + query);
        search.value = "";

    }



});


titleButton.addEventListener("click", function (event) {
    main.innerHTML = ''
    showMovies(apiUrl);
})

